# Placeholder módulo ec2
